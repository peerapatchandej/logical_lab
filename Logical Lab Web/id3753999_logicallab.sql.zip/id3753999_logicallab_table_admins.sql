
-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `Admin_ID` int(4) UNSIGNED ZEROFILL NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Lastname` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Create_Date` datetime NOT NULL,
  `Last_Update` datetime NOT NULL,
  `Role_ID` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`Admin_ID`, `Name`, `Lastname`, `Email`, `Password`, `Create_Date`, `Last_Update`, `Role_ID`) VALUES
(0001, 'Peerapat', 'Chandej', 'logical.lab.coop@gmail.com', 'fabff0ed2ec7dc3e04edcbf3ba306778', '2017-11-27 10:36:00', '2017-12-15 15:43:15', 1),
(0002, 'Brighto', 'Peerapato', '5706021621225@fitm.kmutnb.ac.th', '22043a7506364a90878c8d32505ab6ca', '2017-12-14 15:21:22', '2017-12-15 15:42:53', 2),
(0007, 'Test', 'Test', 'akihiro_bai@hotmail.com', '76008a0ff601863ab1822600e0c4ba68', '2017-12-15 13:37:37', '0000-00-00 00:00:00', 2),
(0008, 'Preecha', 'Chan', 'bright.knw@gmail.com', '27495a597974b979d201c39df6524416', '2017-12-15 15:44:48', '2017-12-15 15:45:30', 2);
