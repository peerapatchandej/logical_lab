
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` int(4) UNSIGNED ZEROFILL NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Surname` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Create_Date` datetime NOT NULL,
  `Level_1` tinyint(1) NOT NULL DEFAULT '0',
  `Level_2` tinyint(1) NOT NULL DEFAULT '0',
  `Level_3` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `Name`, `Surname`, `Email`, `Create_Date`, `Level_1`, `Level_2`, `Level_3`) VALUES
(0085, 'Peerapat', 'Chandej', 'akihiro_bai@hotmail.com', '2017-11-21 01:17:27', 1, 1, 1),
(0086, 'Bright', 'Peerapat', 'bright.knw@gmail.com', '2017-11-21 09:26:09', 1, 1, 1),
(0090, 'Thanawat', 'Umarsa', '5706021622124@fitm.kmutnb.ac.th', '2017-12-13 18:27:12', 1, 0, 0),
(0093, 'Test', 'Test', '5706021621225@fitm.kmutnb.ac.th', '2017-12-15 02:57:46', 1, 1, 1);
